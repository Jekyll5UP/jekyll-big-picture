<h2>TL;DR</h2>

_Tired of configuring & refactoring the SCSS Framework "Spectre" for Jekyll?_
<br>
**Fixed it.**